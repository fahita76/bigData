/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./CustomControl/index.ts":
/*!********************************!*\
  !*** ./CustomControl/index.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   CustomControl: () => (/* binding */ CustomControl)\n/* harmony export */ });\nvar __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {\n  function adopt(value) {\n    return value instanceof P ? value : new P(function (resolve) {\n      resolve(value);\n    });\n  }\n  return new (P || (P = Promise))(function (resolve, reject) {\n    function fulfilled(value) {\n      try {\n        step(generator.next(value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function rejected(value) {\n      try {\n        step(generator[\"throw\"](value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function step(result) {\n      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);\n    }\n    step((generator = generator.apply(thisArg, _arguments || [])).next());\n  });\n};\nclass CustomControl {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this.optionDictionary = {};\n    // Empty\n  }\n  init(context, notifyOutputChanged, state, container) {\n    this.container = container;\n    this.notifyOutputChanged = notifyOutputChanged;\n    this._context = context;\n    // eslint-disable-next-line @typescript-eslint/no-explicit-any\n    var formContext = this.formContext = context.formContext;\n    console.log(this.formContext);\n    // Create input\n    this.inputEl = document.createElement(\"input\");\n    this.inputEl.type = \"text\";\n    this.inputEl.placeholder = \"Search company...\";\n    this.inputEl.value = context.parameters.value.raw || \"\";\n    this.inputEl.style.paddingLeft = \"12px\";\n    this.currentValue = this.inputEl.value;\n    this.inputEl.className = \"fui-Input__input rvp2gzh ___9xd2bv0 f1l02sjl f1cmbuwj fly5x3f f1pivz5x fui-Input r1jtohuq pa-input-component-root ___sv0lv60 f16xq7d1 ftmjh5b f17blpuu f1tpwn32 fsrcdbj fghlq4f f1gn591s fb073pr fjscplz fly5x3f f1l02sjl f1couhl3\";\n    // Create suggestion dropdown\n    this.suggestionBox = document.createElement(\"ul\");\n    this.suggestionBox.style.position = \"absolute\";\n    this.suggestionBox.style.background = \"white\";\n    this.suggestionBox.style.listStyleType = \"none\";\n    this.suggestionBox.style.width = \"308px\";\n    this.suggestionBox.style.zIndex = \"1\";\n    this.suggestionBox.style.fontFamily = \"inherit\";\n    this.suggestionBox.style.fontSize = \"inherit\";\n    this.suggestionBox.style.fontWeight = \"inherit\";\n    this.suggestionBox.style.lineHeight = \"inherit\";\n    this.suggestionBox.style.boxShadow = \"0 2px 10px rgba(0,0,0,0.2)\";\n    this.suggestionBox.hidden = true;\n    // Attach events\n    this.inputEl.addEventListener(\"input\", this.onInputChange.bind(this));\n    this.inputEl.addEventListener(\"blur\", () => setTimeout(() => this.suggestionBox.hidden = true, 200));\n    this.inputEl.addEventListener(\"focus\", () => {\n      if (this.suggestionBox.childElementCount > 0) this.suggestionBox.hidden = false;\n    });\n    // Add elements to container\n    this.container.appendChild(this.inputEl);\n    this.container.appendChild(this.suggestionBox);\n  }\n  onInputChange(e) {\n    return __awaiter(this, void 0, void 0, function* () {\n      var term = e.target.value;\n      this.currentValue = term;\n      this.notifyOutputChanged();\n      if (term.length < 2) {\n        this.clearSuggestions();\n        this.selectedSourceId = \"\";\n        this.selectedEntityStatus = \"\";\n        this.selectedRegistrationDate = undefined;\n        this.notifyOutputChanged();\n        return;\n      }\n      var suggestions = yield this.fetchCompanySuggestions(term);\n      this.clearSuggestions();\n      this.optionDictionary = {};\n      Object.entries(suggestions).forEach(_ref => {\n        var [key, value] = _ref;\n        if (key == 'results') {\n          this.selectedSourceId = \"\";\n          this.selectedEntityStatus = \"\";\n          this.selectedRegistrationDate = undefined;\n          this.notifyOutputChanged();\n          Object.entries(value).forEach(_ref2 => {\n            var [key, value] = _ref2;\n            var recordType = \"\";\n            var recordValue = \"\";\n            var recordTopicSourceId = \"\";\n            Object.entries(value).forEach(_ref3 => {\n              var [key, value] = _ref3;\n              switch (key) {\n                case \"type\":\n                  recordType = value;\n                  break;\n                case \"value\":\n                  recordValue = value;\n                  break;\n                case \"topic_source_id\":\n                  recordTopicSourceId = value;\n                  break;\n              }\n            });\n            if (recordType == 'name') {\n              var li = document.createElement(\"li\");\n              li.textContent = recordValue;\n              li.style.padding = \"4px\";\n              li.style.borderBottom = \"1px solid #ccc\";\n              li.style.cursor = \"pointer\";\n              li.addEventListener(\"mousedown\", () => this.onSelectSuggestion(recordValue));\n              this.suggestionBox.appendChild(li);\n              this.optionDictionary[recordTopicSourceId] = recordValue;\n            }\n          });\n        }\n      });\n      this.suggestionBox.hidden = suggestions.length === 0;\n      if (this.suggestionBox.childElementCount === 0) {\n        //No match found, clear related values\n        this.selectedSourceId = \"\";\n        this.selectedEntityStatus = \"\";\n        this.selectedRegistrationDate = undefined;\n        this.notifyOutputChanged();\n      }\n    });\n  }\n  clearSuggestions() {\n    this.suggestionBox.innerHTML = \"\";\n    this.suggestionBox.hidden = true;\n  }\n  fetchCompanySuggestions(query) {\n    return __awaiter(this, void 0, void 0, function* () {\n      try {\n        var resp = yield fetch(\"https://orgbook.gov.bc.ca/api/v4/search/autocomplete?q=\".concat(encodeURIComponent(query), \"&inactive=false&revoked=false\"));\n        if (!resp.ok) throw new Error(resp.statusText);\n        return yield resp.json(); // expects an array of names\n      } catch (err) {\n        console.error(\"API error:\", err);\n        return [];\n      }\n    });\n  }\n  renderSuggestions(suggestions, context) {\n    this.clearSuggestions();\n    suggestions.forEach(s => {\n      var li = document.createElement(\"li\");\n      li.textContent = s;\n      li.style.padding = \"4px\";\n      li.style.cursor = \"pointer\";\n      li.addEventListener(\"mousedown\", () => this.onSelectSuggestion(s));\n      this.suggestionBox.appendChild(li);\n    });\n    this.suggestionBox.hidden = suggestions.length === 0;\n  }\n  onSelectSuggestion(value) {\n    return __awaiter(this, void 0, void 0, function* () {\n      this.currentValue = value;\n      this.inputEl.value = value;\n      Object.entries(this.optionDictionary).forEach(_ref4 => {\n        var [key, value] = _ref4;\n        if (value == this.currentValue) {\n          this.selectedSourceId = key;\n        }\n      });\n      var topic = yield this.GetTopic(this.selectedSourceId);\n      Object.entries(topic).forEach(_ref5 => {\n        var [key, value] = _ref5;\n        if (key == \"results\") {\n          Object.entries(value).forEach(_ref6 => {\n            var [key, value] = _ref6;\n            Object.entries(value).forEach(_ref7 => {\n              var [key, value] = _ref7;\n              if (key == \"attributes\") {\n                Object.entries(value).forEach(_ref8 => {\n                  var [key, value] = _ref8;\n                  var recordtype = \"\";\n                  Object.entries(value).forEach(_ref9 => {\n                    var [key, value] = _ref9;\n                    if (key == \"type\") {\n                      recordtype = value;\n                    }\n                    if (key == \"value\" && recordtype == \"registration_date\") {\n                      this.selectedRegistrationDate = new Date(value);\n                    }\n                    if (key == \"value\" && recordtype == \"entity_status\") {\n                      this.selectedEntityStatus = value;\n                    }\n                  });\n                });\n              }\n            });\n          });\n        }\n      });\n      this.clearSuggestions();\n      this.notifyOutputChanged();\n    });\n  }\n  GetTopic(query) {\n    return __awaiter(this, void 0, void 0, function* () {\n      try {\n        var resp = yield fetch(\"https://orgbook.gov.bc.ca/api/v4/search/topic?ordering=-score&q=\".concat(encodeURIComponent(query), \"&inactive=false&latest=true&revoked=false\"));\n        if (!resp.ok) throw new Error(resp.statusText);\n        //add logic here\n        return yield resp.json();\n      } catch (err) {\n        console.error(\"API error:\", err);\n        return [];\n      }\n    });\n  }\n  updateView(context) {\n    // If underlying value changed from CRM (e.g. form refresh), update the display\n    if (context.parameters.value.raw !== this.currentValue) {\n      this.currentValue = context.parameters.value.raw || \"\";\n      this.inputEl.value = this.currentValue;\n      this.selectedSourceId = context.parameters.sourceId.raw || \"\";\n      this.selectedRegistrationDate = context.parameters.registrationDate.raw || new Date();\n      this.selectedEntityStatus = context.parameters.entityStatus.raw || \"\";\n    }\n  }\n  getOutputs() {\n    return {\n      value: this.currentValue,\n      sourceId: this.selectedSourceId,\n      registrationDate: this.selectedRegistrationDate,\n      entityStatus: this.selectedEntityStatus\n    };\n  }\n  destroy() {\n    // Clean up\n    this.inputEl.remove();\n    this.suggestionBox.remove();\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./CustomControl/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./CustomControl/index.ts"](0, __webpack_exports__, __webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('AutoComplete.CustomControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CustomControl);
} else {
	var AutoComplete = AutoComplete || {};
	AutoComplete.CustomControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CustomControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}